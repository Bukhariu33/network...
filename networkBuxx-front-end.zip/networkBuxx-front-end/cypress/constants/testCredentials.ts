export const adminData = {
  email: 'super@test.com',
  password: 'password',
};
export const fundManagerData = {
  email: 'fund-manager@test.com',
  password: 'password',
};
export const individualInvestorData = {
  email: 'individual-investor@test.com',
  password: 'password',
};
export const corporateInvestorData = {
  email: 'corporate-investor@test.com',
  password: 'password',
};

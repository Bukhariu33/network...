const VotingOnFundDecisionsPanel = () => {
  return <div>voting on fund decisions</div>;
};

export default VotingOnFundDecisionsPanel;

export const styleConfig = {
  infoCardClassNames: {
    valueClassName: 'sm:text-lg leading-[1.33333] font-bold',
    wrapperClassName: 'gap-[5px] ltr:pr-[20px] rtl:pl-[20px]',
  },
};

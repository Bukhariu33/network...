interface IOptions {
  paths: {
    authPaths: string[];
    publicPaths?: string[];
    adminPaths?: string[];
    investorPaths?: string[];
    investorKycPaths?: string[];
    fundManagerPaths?: string[];
  };
}

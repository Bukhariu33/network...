import { InfoModal } from './info-modal';

export * from './confirm';
export * from './error';
export * from './info-modal';
export * from './success';
export const modals = {
  info: InfoModal,
  /* ...other modals */
};

interface ChartDataItem {
  name: string;
  value: number;
  color?: string;
}

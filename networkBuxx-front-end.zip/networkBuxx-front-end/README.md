# Eads - Web App

## Installation

```bash
pnpm install
```

## Development

```bash
pnpm dev
```

## env

```bash
copy .env.example .env
```

<!-- // -->
